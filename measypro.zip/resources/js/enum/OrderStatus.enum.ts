export enum OrderStatusEnum {
    GENERATED = "generated",
    PENDING = "pending",
    RECEIVED = "received",
}