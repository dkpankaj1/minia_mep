export enum PaymentStatusEnum {
    PENDING = "pending",
    PARTIAL = "partial",
    PAID = "paid",
}