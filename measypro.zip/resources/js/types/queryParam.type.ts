export type TQueryParam = {
    [key: string]: string | number;
}