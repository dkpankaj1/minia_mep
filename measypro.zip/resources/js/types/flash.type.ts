export type TFlashType = {
    success: string;
    danger: string;
}