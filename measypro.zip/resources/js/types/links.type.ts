export type TLinksType = {
    url : string;
    label : string;
    active:boolean;
}