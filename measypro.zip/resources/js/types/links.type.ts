export type TLinksType = {
    label: string;
    url: string;
    active?: boolean;
}