import React from 'react'

function FormInput({ ...props }) {
    return (
        <input {...props} />
    )
}

export default FormInput