<?php
namespace App\Enums;

enum DiscountTypeEnum
{
    // public const FIXED = 'fixed';
    // public const PERCENTAGE = 'percentage';

    public const FIXED = 0;
    public const PERCENTAGE = 1;
}

