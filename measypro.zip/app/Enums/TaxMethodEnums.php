<?php
namespace App\Enums;

enum TaxMethodEnums: string
{
    const INCLUSIVE = 0;
    const EXCLUSIVE = 1;
}

