<!DOCTYPE html>
<html lang="en">

<head>

    <title>Recept No. - <?php echo e($purchase->id); ?> | Purchase Invoice </title>
    <style>
        body {
            border: double 1px #000;
            height: 267mm;
            box-sizing: border-box;
            font-size: .6rem;
            font-family: "Lucida Console", "Courier New", monospace;
            position: relative;
            margin: 0;
            padding: 0;
        }

        .footer {
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        .item_list {
            height: 180mm;
            overflow: auto;
        }

        .td,
        .tr,
        .th {
            font-size: .5rem;
        }

        .border {
            border-collapse: collapse;
        }

        .border,
        .border th,
        .border td {
            padding: .25rem;
            border: 1px solid #000;
        }
    </style>
</head>

<body>

    <header>

        <div>
            <div style="margin:2.5mm 0mm">
                <center>
                    <span style="font-size: 1.5rem;font-weight:bold"><?php echo e($company->name); ?></span><br />
                    <small style="font-size: 0.7rem;font-wait:bold; text-transform: uppercase">
                        <?php echo e($company->address); ?>,
                        <?php echo e($company->city); ?>, <?php echo e($company->state); ?>, <?php echo e($company->country); ?>

                        (<?php echo e($company->postal_code); ?>)
                    </small>
                    <br />
                    <small style="font-size: 0.7rem;font-wait:bold;"><?php echo e($company->phone); ?>, <?php echo e($company->email); ?></small>
                    <br>
                    <span> <b>GST : </b>09GKQPS5130F1ZP</span>
                </center>
            </div>

            <table style="width: 100%;border-bottom:solid 1px;border-top:solid 1px;margin-top:1mm">
                <tr>
                    <td>
                        <b>Recept No. : </b> <?php echo e($purchase->id); ?> <br />
                    </td>
                    <td style="text-align:right;">
                        <b>Date :</b> <?php echo e(\Carbon\Carbon::parse($purchase->date)->format('Y-m-d')); ?>

                    </td>
                </tr>
            </table>

            <table style="width: 100%; border-top: solid 1px; margin-top: 1mm;">
                <tr style="border-bottom: solid 1px;">
                    <td style="width: 50%; text-align: left;">
                        <div>
                            <h3 style="margin: 2px 0;">Billed From:</h3>
                            <h3 style="margin: 2px 0;"><?php echo e($purchase->supplier->name); ?></h3>
                            <p style="margin: 2px 0; font-size: 10px;">
                                <?php echo e($purchase->supplier->address); ?>,<?php echo e($purchase->supplier->city); ?></p>
                            <p style="margin: 2px 0; font-size: 10px;"><?php echo e($purchase->supplier->state); ?>,
                                <?php echo e($purchase->supplier->country); ?> (<?php echo e($purchase->supplier->postal_code); ?>)</p>
                            <p style="margin: 2px 0; font-size: 10px;"><?php echo e($purchase->supplier->phone); ?>,
                                <?php echo e($purchase->supplier->email); ?></p>
                        </div>
                    </td>
                    <td style="width: 50%; text-align: right;">
                        <div>
                            <h3 style="margin: 2px 0;">Billed To:</h3>
                            <h3 style="margin: 2px 0;"><?php echo e($company->name); ?></h3>
                            <p style="margin: 2px 0; font-size: 10px;"><?php echo e($company->address); ?>,<?php echo e($company->city); ?>

                            </p>
                            <p style="margin: 2px 0; font-size: 10px;"><?php echo e($company->state); ?>, <?php echo e($company->country); ?>

                                (<?php echo e($company->postal_code); ?>)</p>
                            <p style="margin: 2px 0; font-size: 10px;"><?php echo e($company->phone); ?>, <?php echo e($company->email); ?>

                            </p>
                        </div>
                    </td>
                </tr>
            </table>

        </div>

    </header>



    <main>
        <table class="border item_list" style="width: 100%">

            <tr style="background-color:#3d3c3c;color:#fff;border:solid 1px #000">
                <th style="text-align:center">SR</th>
                <th style="text-align:center">Items</th>
                <th style="text-align:center">Code</th>
                <th style="text-align:center">Rate (<?php echo e($system->currency->short_name); ?>)</th>
                <th style="text-align:center">Qnt</th>
                <th style="text-align:center">Unit</th>
                <th style="text-align:center">Total (<?php echo e($system->currency->short_name); ?>)</th>
            </tr>

            <?php
                $space = 160;
            ?>
            <?php $__currentLoopData = $purchase->purchaseItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <?php
                    $quantity =
                        $item->purchaseUnit->operator == '/'
                            ? $item->quantity / $item->purchaseUnit->operator_value
                            : $item->quantity * $item->purchaseUnit->operator_value;

                    $discounted_price =
                        $item->discount_method == '0'
                            ? $item->net_unit_cost - $item->discount
                            : $item->net_unit_cost * (1 - $item->discount / 100);

                    $taxed_price =
                        $item->tax_method == '0'
                            ? $discounted_price
                            : $discounted_price * (1 + $item->tax_rate / 100);

                    $sub_total = $quantity * $taxed_price;
                ?>

                    <td style="text-align:center"><?php echo e($key + 1); ?></td>
                    <td style="text-align:center"><?php echo e($item->product->name); ?></td>
                    <td style="text-align:center"><?php echo e($item->product->code); ?></td>
                    <td style="text-align:center"><?php echo e(round($taxed_price,2)); ?></td>
                    <td style="text-align:center"><?php echo e($item->quantity); ?></td>
                    <td style="text-align:center"><?php echo e($item->purchaseUnit->short_name); ?></td>               
                    <td style="text-align:center"><?php echo e(round($sub_total, 2)); ?></td>
                </tr>
                <?php
                    $space = $space - 5;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <tr>
                <td>
                    <div style="min-height: <?php echo e($space); ?>mm"></div>
                </td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>

            <tr>
                <td colspan="6" style="text-align:right;"><b>Total
                        (<?php echo e($system->currency->short_name); ?>)</b>
                </td>
                <td colspan="1">
                    <b><?php echo e(round($purchase->total_cost, 2)); ?></b>
                </td>
            </tr>

            <tr>
                <td colspan="6">
                    <table style="width: 100%;">
                        <tr>
                            <th style="border:0;text-align:center">Shipping Cost (<?php echo e($system->currency->short_name); ?>)
                            </th>
                            <th style="border:0;text-align:center">Other Cost (<?php echo e($system->currency->short_name); ?>)
                            </th>
                            <th style="border:0;text-align:center">Discount (<?php echo e($system->currency->short_name); ?>)</th>
                            <th style="border:0;text-align:center">Tax (%)</th>
                        </tr>
                        <tr>
                            <td style="border:0;text-align:center"><?php echo e($purchase->shipping_cost); ?></td>
                            <td style="border:0;text-align:center"><?php echo e($purchase->other_cost); ?></td>
                            <td style="border:0;text-align:center">
                                <?php echo e(round(
                                    $purchase->discount_method == '0' ? $purchase->discount : $purchase->total_cost * ($item->discount / 100),
                                    2,
                                )); ?>

                            </td>

                            <td style="border:0;text-align:center"><?php echo e(round($purchase->total_tax)); ?>

                                (<?php echo e($purchase->tax_rate); ?> %)</td>
                        </tr>
                    </table>
                </td>
                <td colspan="1"></td>
            </tr>


            <tr>
                <td colspan="6" style="text-align:right;"><b>Grand Total
                        (<?php echo e($system->currency->short_name); ?>)</b>
                </td>
                <td colspan="1"> <b><?php echo e(round($purchase->grand_total, 2)); ?></b></td>
            </tr>

            <tr>
                <td colspan="6" style="text-align:right;"><b>Paid Amount
                        (<?php echo e($system->currency->short_name); ?>)</b>
                </td>
                <td colspan="1"><b><?php echo e(round($purchase->paid_amount, 2)); ?></b></td>
            </tr>

        </table>
    </main>





    <footer>
        <div class="footer">
            <table style="width: 100%; margin-top:10mm">
                <tr>
                    <td style="text-align:left;padding: 0px .25rem">
                        <span>Receiver's signature</span>
                    </td>
                    <td style="text-align:right;padding: 0px .25rem">
                        <span>Authorised signature</span>
                    </td>
                </tr>
            </table>
            <table class="border" style="width: 100%; margin-top:5mm">
                <tr>
                    <td>
                        <small style="padding:0.5mm">
                            <b>Note :</b> <?php echo e($purchase->note); ?>

                        </small>

                    </td>
                </tr>
            </table>
        </div>
    </footer>



</body>

</html>
<?php /**PATH C:\Users\CortexItSolution\Documents\php Project\measypro\resources\views/invoices/purchase/pdf.blade.php ENDPATH**/ ?>