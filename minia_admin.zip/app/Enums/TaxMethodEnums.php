<?php
namespace App\Enums;

enum TaxMethodEnums: string
{
    const INCLUSIVE = 1;
    const EXCLUSIVE = 0;
}

