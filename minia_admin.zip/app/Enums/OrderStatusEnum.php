<?php

namespace App\Enums;

enum OrderStatusEnum {
    public const GENERATED  = "generated";
    public const PENDING  = "pending";
    public const RECEIVED  = "received";
}